from .base import *

STATIC_ROOT = '/local/static'
DEBUG = False
