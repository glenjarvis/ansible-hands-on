
virtualenv
==========

`Changes & News <news.html>`_ |
`Mailing list <http://groups.google.com/group/python-virtualenv>`_ |
`Issues <https://github.com/pypa/virtualenv/issues>`_ |
`Github <https://github.com/pypa/virtualenv>`_ |
`PyPI <https://pypi.python.org/pypi/virtualenv/>`_ |
IRC: #pip

.. comment: split here


.. toctree::
   :maxdepth: 2

   virtualenv
